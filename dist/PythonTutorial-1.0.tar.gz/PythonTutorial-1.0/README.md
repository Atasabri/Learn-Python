Hi ..
This Package For Learn Python Tutorial
In test.py & preview.py You Can Find All Python Tutorials

# Note That use pipenv by write => pipenv install on CMD

UnComment Code And Run

# Variables

# Strings

# Escape Sequences

# Concatination

# Numbers

# Convertion

# If Statment

# Ternary Operator

# Operators

# Chaining

# For Loops

# While Loops

# Functions

# Lists =========== >> [1,2,3,4] list()

# Sets =========== >> {1,2,3,4} set()

# Tuples =========== >> (1,2,3,4) tuple()

# Dictionaries ====== >> {"key":value,"key":value} dict()

# Arrays =========== >> array("i",[1,2,3,4]) array()

# Itrable (Range) === >> range(5)

# Classes

# Private Members

# Properites (Decoder , Function)

# Constractor

# Container

# Multi Inheritance

# ClassMethod & Static Method

# Overriding (super()) , Magic Methods

# Abstract Class & Abstract Method

# Polymorphism

# Module

# Package

# Sub Package

# Working With Path

# Working With Directories

# Working With Files

# Working With Zip Files

# Working With Excel Files

# Working With Json Files (Json Data)

# Working With Sqlite

# Time

# DateTime , TimeDelta

# Random

# string Module

# webbrowser

# Emails (Tempaltes)

# SubProcess
